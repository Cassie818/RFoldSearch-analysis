"""Supplementary k-mer-length sweep at fixed VQ-VAE codebook size K=80."""
import sys as _sys, os as _os
_sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "..", ".."))
from paths import DATA_ROOT, FIG_DIR, resolve
_os.chdir(DATA_ROOT)
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans"]
import matplotlib.pyplot as plt

KS = np.array([3, 4, 5, 6])
rows = [json.load(open(resolve(f"files/ablation/kmer_k{k}_K80_cosine_neutral.json")))["K80"]
        for k in KS]
fam = np.array([r["fam_sens_mean"] for r in rows])
fam_sd = np.array([r["fam_sens_std"] for r in rows])
clan = np.array([r["clan_sens_mean"] for r in rows])
clan_sd = np.array([r["clan_sens_std"] for r in rows])
post = np.array([r["postings_per_query_mean"] for r in rows])
post_sd = np.array([r["postings_per_query_std"] for r in rows])

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 4.8))
C1, C2, C3 = "#5B7C99", "#B08D5C", "#4C8C69"
ax1.plot(KS, fam, "o-", color=C1, linewidth=2, markersize=7,
         markerfacecolor=C1, markeredgecolor="white", markeredgewidth=1,
         label="Family Sens@1FP", zorder=3)
ax1.plot(KS, clan, "s-", color=C2, linewidth=2, markersize=7,
         markerfacecolor=C2, markeredgecolor="white", markeredgewidth=1,
         label="Clan Sens@1FP", zorder=3)
for values, errors, color in ((fam, fam_sd, C1), (clan, clan_sd, C2)):
    for x, value, error in zip(KS, values, errors):
        ax1.vlines(x, value, value + error, colors="#333333", linewidth=1.0, alpha=0.9)
        ax1.hlines(value + error, x - 0.08, x + 0.08, colors="#333333", linewidth=1.0, alpha=0.9)
        ax1.text(x, value + error + 0.012, f"{value:.3f}", ha="center", fontsize=8, color=color)
ax1.set_xlabel("k-mer length $k$", fontsize=12)
ax1.set_ylabel("Sens@1FP", fontsize=11)
ax1.set_xticks(KS)
ax1.set_ylim(0, 0.60)
ax1.spines[["top", "right"]].set_visible(False)
ax1.text(-0.09, 1.04, "A", transform=ax1.transAxes, fontsize=16,
         fontweight="bold", ha="right")

ax2.plot(KS, post, "o-", color=C3, linewidth=2, markersize=7,
         markerfacecolor=C3, markeredgecolor="white", markeredgewidth=1,
         label="Postings/query", zorder=3)
for x, value, error in zip(KS, post, post_sd):
    ax2.vlines(x, value, value + error, colors="#333333", linewidth=1.0, alpha=0.9)
    ax2.hlines(value + error, x - 0.08, x + 0.08, colors="#333333", linewidth=1.0, alpha=0.9)
    ax2.annotate(f"{value / 1000:.1f}k", (x, value + error), xytext=(0, 7),
                 textcoords="offset points", ha="center", fontsize=8, color=C3)
ax2.set_yscale("log")
ax2.set_xlabel("k-mer length $k$", fontsize=12)
ax2.set_ylabel("Postings per query", fontsize=11)
ax2.set_xticks(KS)
ax2.set_ylim(8e2, 1.5e5)
ax2.spines[["top", "right"]].set_visible(False)
ax2.text(-0.09, 1.04, "B", transform=ax2.transAxes, fontsize=16,
         fontweight="bold", ha="right")

h1, l1 = ax1.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
fig.legend(h1 + h2, l1 + l2, loc="lower center", ncol=3, frameon=False,
           fontsize=12, bbox_to_anchor=(0.5, -0.02), handlelength=1.8,
           columnspacing=2.2)
fig.tight_layout(rect=(0, 0.05, 1, 1))
out = Path(FIG_DIR) / "supp_kmer_length.png"
fig.savefig(out, dpi=200, bbox_inches="tight")
print(f"wrote {out}")
