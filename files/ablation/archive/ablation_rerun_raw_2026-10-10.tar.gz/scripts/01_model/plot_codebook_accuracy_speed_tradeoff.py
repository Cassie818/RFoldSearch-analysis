"""Pareto-style accuracy/selectivity plot for the cosine-matrix codebook sweep."""
import sys as _sys, os as _os
_sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "..", ".."))
from paths import FIG_DIR, resolve
_os.chdir(resolve("."))
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans"]
import matplotlib.pyplot as plt

KS = [20, 40, 60, 80, 100]
POST = np.array([292129.58, 52096.90, 27931.70, 17349.96, 14619.04])
POST_SD = np.array([87207.32, 15907.85, 6665.73, 4875.27, 3184.73])
FAM, FAM_SD, CLAN, CLAN_SD = [], [], [], []
for K in KS:
    p = resolve(f"files/ablation/cv_s4_cosine_K{K}_neutral.json")
    if K in (20, 40, 80):
        p = resolve(f"files/ablation/cv_s4_K{K}_neutral.json")
    d = json.load(open(p))[f"K{K}"]
    FAM.append(d["fam_sens_mean"]); FAM_SD.append(d["fam_sens_std"])
    CLAN.append(d["clan_sens_mean"]); CLAN_SD.append(d["clan_sens_std"])

fig, axes = plt.subplots(1, 2, figsize=(8.8, 4.1), sharex=True)
colors = ["#5B7C99", "#B08D5C"]
for ax, y, e, label, color in zip(
    axes, [FAM, CLAN], [FAM_SD, CLAN_SD], ["Family", "Clan"], colors):
    ax.errorbar(POST, y, xerr=POST_SD, yerr=e, fmt="o-", color=color,
                lw=2, ms=7, capsize=3, zorder=3)
    for K, x, yy in zip(KS, POST, y):
        ax.annotate(f"K={K}", (x, yy), xytext=(0, 10), textcoords="offset points",
                    ha="center", fontsize=8.5, color=color)
    ax.set_xscale("log")
    ax.set_xlabel("Postings per query (lower = faster)")
    ax.set_ylabel(f"{label} Sens@1FP")
    ax.set_ylim(0.04 if label == "Clan" else 0.35, 0.58 if label == "Family" else 0.20)
    ax.grid(axis="both", alpha=0.22, linewidth=0.7)
    ax.spines[["top", "right"]].set_visible(False)
    ax.invert_xaxis()

fig.suptitle("Accuracy–speed trade-off across codebook sizes", y=1.02, fontsize=12)
fig.tight_layout()
out = Path(FIG_DIR) / "codebook_accuracy_speed_tradeoff.png"
fig.savefig(out, dpi=220, bbox_inches="tight")
print(f"wrote {out}")
