"""Clean two-panel accuracy/selectivity plot for the cosine codebook sweep."""
import sys as _sys, os as _os
_sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "..", ".."))
from paths import FIG_DIR, resolve
_os.chdir(resolve("."))
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans"]
import matplotlib.pyplot as plt

KS = np.array([20, 40, 60, 80, 100])
POST = np.array([292129.58, 52096.90, 27931.70, 17349.96, 14619.04])
POST_SD = np.array([87207.32, 15907.85, 6665.73, 4875.27, 3184.73])
fam = []; fam_sd = []; clan = []; clan_sd = []
for K in KS:
    p = resolve(f"files/ablation/cv_s4_cosine_K{K}_neutral.json")
    if int(K) in (20, 40, 80): p = resolve(f"files/ablation/cv_s4_K{K}_neutral.json")
    d = json.load(open(p))[f"K{K}"]
    fam.append(d["fam_sens_mean"]); fam_sd.append(d["fam_sens_std"])
    clan.append(d["clan_sens_mean"]); clan_sd.append(d["clan_sens_std"])

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 4.8))
C1, C2, C3 = "#5B7C99", "#B08D5C", "#4C8C69"
fam = np.asarray(fam); fam_sd = np.asarray(fam_sd)
clan = np.asarray(clan); clan_sd = np.asarray(clan_sd)
ax1.plot(KS, fam, "o-", color=C1, linewidth=2, markersize=7,
         markerfacecolor=C1, markeredgecolor="white", markeredgewidth=1,
         label="Family Sens@1FP", zorder=3)
ax1.plot(KS, clan, "s-", color=C2, linewidth=2, markersize=7,
         markerfacecolor=C2, markeredgecolor="white", markeredgewidth=1,
         label="Clan Sens@1FP", zorder=3)
for values, errors in ((fam, fam_sd), (clan, clan_sd)):
    for x, value, error in zip(KS, values, errors):
        ax1.vlines(x, value, value + error, colors="#333333", linewidth=1.0, alpha=0.9)
        ax1.hlines(value + error, x - 2.0, x + 2.0, colors="#333333", linewidth=1.0, alpha=0.9)
for x, value, error in zip(KS, fam, fam_sd):
    ax1.text(x, value + error + 0.012, f"{value:.3f}", ha="center",
             fontsize=8, color=C1)
for x, value, error in zip(KS, clan, clan_sd):
    ax1.text(x, value + error + 0.012, f"{value:.3f}", ha="center",
             fontsize=8, color=C2)
ax1.set_xlabel("Codebook size $K$", fontsize=12)
ax1.set_ylabel("Sens@1FP", fontsize=11)
ax1.set_xticks(KS)
ax1.set_ylim(0, 0.58)
ax1.spines[["top", "right"]].set_visible(False)
ax1.text(-0.09, 1.04, "A", transform=ax1.transAxes, fontsize=16,
         fontweight="bold", ha="right")

ax2.plot(KS, POST, "o-", color=C3, linewidth=2, markersize=7,
         markerfacecolor=C3, markeredgecolor="white", markeredgewidth=1,
         label="Postings/query", zorder=3)
for x, value, error in zip(KS, POST, POST_SD):
    ax2.vlines(x, value, value + error, colors="#333333", linewidth=1.0, alpha=0.9)
    ax2.hlines(value + error, x - 2.0, x + 2.0, colors="#333333", linewidth=1.0, alpha=0.9)
    ax2.annotate(f"{value / 1000:.1f}k", (x, value + error),
                 xytext=(0, 7), textcoords="offset points", ha="center",
                 fontsize=8, color=C3)
ax2.set_yscale("log")
ax2.set_ylabel("Postings per query", fontsize=11)
ax2.set_xlabel("Codebook size $K$", fontsize=12)
ax2.set_xticks(KS)
ax2.set_ylim(9e3, 5e5)
ax2.spines[["top", "right"]].set_visible(False)
ax2.text(-0.09, 1.04, "B", transform=ax2.transAxes, fontsize=16,
         fontweight="bold", ha="right")

out = Path(FIG_DIR) / "supp_codebook_size.png"
handles1, labels1 = ax1.get_legend_handles_labels()
handles2, labels2 = ax2.get_legend_handles_labels()
fig.legend(handles1 + handles2, labels1 + labels2, frameon=False, ncol=3,
           loc="lower center", bbox_to_anchor=(0.5, -0.02), fontsize=12,
           handlelength=1.8, columnspacing=2.2)
fig.tight_layout(rect=(0, 0.05, 1, 1))
fig.savefig(out, dpi=200, bbox_inches="tight", facecolor="white")
print(f"wrote {out}")
