"""Plot cosine-matrix codebook ablation with retrieval and prefilter selectivity."""
import sys as _sys, os as _os

_sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "..", ".."))
from paths import FIG_DIR, resolve
_os.chdir(resolve("."))
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans"]
import matplotlib.pyplot as plt

KS = [20, 40, 60, 80, 100]
sens = {}
for K in KS:
    p = resolve(f"files/ablation/cv_s4_cosine_K{K}_neutral.json")
    if K in (20, 40, 80):
        # These were generated before the cosine-specific filenames were used.
        p = resolve(f"files/ablation/cv_s4_K{K}_neutral.json")
    d = json.load(open(p))[f"K{K}"]
    sens[K] = (d["fam_sens_mean"], d["fam_sens_std"],
               d["clan_sens_mean"], d["clan_sens_std"])

# Full Structure-BLOSUM-expanded prefilter postings/query, cosine matrix.
post = {
    20: (292129.58, 87207.32),
    40: (52096.90, 15907.85),
    60: (27931.70, 6665.73),
    80: (17349.96, 4875.27),
    100: (14619.04, 3184.73),
}

fam = np.array([sens[K][0] for K in KS])
fam_sd = np.array([sens[K][1] for K in KS])
clan = np.array([sens[K][2] for K in KS])
clan_sd = np.array([sens[K][3] for K in KS])
pq = np.array([post[K][0] for K in KS])
pq_sd = np.array([post[K][1] for K in KS])

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9.3, 4.0), gridspec_kw={"wspace": 0.32})
C1, C2, C3 = "#5B7C99", "#B08D5C", "#4C8C69"

ax1.errorbar(KS, fam, yerr=fam_sd, fmt="o-", color=C1, lw=2, ms=6,
             capsize=3, label="Family Sens@1FP")
ax1.errorbar(KS, clan, yerr=clan_sd, fmt="s-", color=C2, lw=2, ms=6,
             capsize=3, label="Clan Sens@1FP")
ax1.set_xlabel("Codebook size $K$")
ax1.set_ylabel("Sens@1FP")
ax1.set_xticks(KS)
ax1.set_ylim(0, 0.60)
ax1.grid(axis="y", alpha=0.22, linewidth=0.7)
ax1.spines[["top", "right"]].set_visible(False)
ax1.legend(frameon=False, fontsize=9, loc="upper right")
for k, v in zip(KS, fam):
    ax1.annotate(f"{v:.3f}", (k, v), xytext=(0, 8), textcoords="offset points",
                 ha="center", fontsize=8, color=C1)

ax2.errorbar(KS, pq, yerr=pq_sd, fmt="o-", color=C3, lw=2, ms=6,
             capsize=3)
ax2.set_xlabel("Codebook size $K$")
ax2.set_ylabel("Postings per query")
ax2.set_xticks(KS)
ax2.set_yscale("log")
ax2.grid(axis="y", which="both", alpha=0.22, linewidth=0.7)
ax2.spines[["top", "right"]].set_visible(False)
for k, v in zip(KS, pq):
    ax2.annotate(f"{v/1000:.1f}k", (k, v), xytext=(0, 8), textcoords="offset points",
                 ha="center", fontsize=8, color=C3)

fig.suptitle("Cosine-matrix codebook sweep", y=1.02, fontsize=12)
fig.tight_layout()
out = Path(FIG_DIR) / "supp_codebook_size_postings.png"
out.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(out, dpi=220, bbox_inches="tight")
print(f"wrote {out}")
